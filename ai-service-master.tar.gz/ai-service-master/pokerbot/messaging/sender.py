import pika
import json

def send_bot_message(username, bot_response):
   bot_message = {}
   bot_message['userName'] = username
   bot_message['botMessage'] = bot_response
   json_data = json.dumps(bot_message)

   parameters = pika.URLParameters("amqps://gsdiawll:jamc4tjScGROy4z4vbFZyo0lGYxJ0jEu@chinook.rmq.cloudamqp.com/gsdiawll")
   connection = pika.BlockingConnection(parameters)
   channel = connection.channel()
   channel.queue_declare(queue="botMessages", durable=True)
   channel.basic_publish(exchange='',
                         routing_key='botMessages',
                         body=json_data)
   print("Sent bot response to queue")
   connection.close()
   
