import json
import pickle
import pika
from keras.models import load_model
from chatbot.chatbot import lemmatize, chatbot_response
from chatbot.train import setup_training
from chatbot.model import create_and_train_model
from messaging.sender import send_bot_message

def main():
    ignore_words = ['?', '!', ',']
    data_file = open('pokerbot/intents.json').read()
    intents = json.loads(data_file)
    lemmatize(ignore_words, intents)
    words = pickle.load(open('pokerbot/transform/words.pkl', 'rb'))
    classes = pickle.load(open('pokerbot/transform/classes.pkl', 'rb'))
    documents = pickle.load(open('pokerbot/transform/documents.pkl', 'rb'))
    training_set_patterns, training_set_intents = setup_training(words, classes, documents)
    create_and_train_model(training_set_patterns, training_set_intents)
    model = load_model('pokerbot/chatbot/chatbot_model.h5')
    receive_player_message(words, classes, model, intents)

def receive_player_message(words, classes, model, intents):
    parameters = pika.URLParameters("amqps://gsdiawll:jamc4tjScGROy4z4vbFZyo0lGYxJ0jEu@chinook.rmq.cloudamqp.com/gsdiawll")
    connection = pika.BlockingConnection(parameters)
    channel = connection.channel()
    channel.queue_declare(queue='playerMessages', durable=True)

    def callback(channel, method, properties, body):
        player_message_json = json.loads(body)
        player_message = ''
        if player_message_json['playerMessage'] == '!help':
            player_message = player_message_json['handScore']
        else:
            player_message = player_message_json['playerMessage']
        bot_response = chatbot_response(player_message, words, classes, model, intents)
        send_bot_message(player_message_json['userName'], bot_response)

    channel.basic_consume(queue='playerMessages', on_message_callback=callback, auto_ack=True)
    channel.start_consuming()


if __name__ == '__main__':
    main()
