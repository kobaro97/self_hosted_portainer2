import nltk
import random
import math
import numpy as np
import pickle
import json
nltk.download('punkt')
nltk.download('wordnet')
from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
from keras.models import load_model


words = pickle.load(open('pokerbot/transform/words.pkl','rb'))
classes = pickle.load(open('pokerbot/transform/classes.pkl','rb'))
model = load_model('pokerbot/chatbot/chatbot_model.h5')

def lemmatize(ignore_words,intents):
    words = []
    classes = []
    documents = []
    for intent in intents['intents']:
        for pattern in intent['patterns']:
            #take each word and tokenize it
            w = nltk.word_tokenize(pattern)
            words.extend(w)
            documents.append((w, intent['tag']))

            if intent['tag'] not in classes:
                classes.append(intent['tag'])
    # lemmatize = turn a word into base meaning => working becomes work etc ...
    words = [lemmatizer.lemmatize(w.lower()) for w in words if w not in ignore_words]
    words = sorted(list(set(words)))
    classes = sorted(list(set(classes)))
    
    print (len(documents), "documents")
    print (len(classes), "classes", classes)
    print (len(words), "unique lemmatized words", words)

    #wb means write binary
    pickle.dump(words,open('pokerbot/transform/words.pkl','wb'))
    pickle.dump(classes,open('pokerbot/transform/classes.pkl','wb'))
    pickle.dump(documents,open('pokerbot/transform/documents.pkl','wb'))

def clean_up_sentence(sentence):
    sentence_words = nltk.word_tokenize(sentence)
    sentence_words = [lemmatizer.lemmatize(sentence_word.lower()) for sentence_word in sentence_words]
    return sentence_words

# return bag of words of 0/1s for each word in the bag that exists in the sentence

def bow(sentence, words, show_details=False):
    #tokenize the pattern
    sentence_words = clean_up_sentence(sentence)
    # bag of words - matrix of N words, vocabulary matrix
    bag = [0]*len(words)
    for sentence_word in sentence_words:
        for i,word in enumerate(words):
            if word == sentence_word:
                # assign 1 if current word is in the vocabulary position
                bag[i] = 1
                if show_details:
                    print ("found in bag: %s" % word)
    return(np.array(bag))

def predict_class(sentence,words,classes,model):
    # filter out predictions below a threshold
    contained_words = bow(sentence,words,show_details=False)
    predictions = model.predict(np.array([contained_words]))[0]
    ERROR_THRESHOLD = 0.25
    results = [[i,prediction] for i,prediction in enumerate(predictions) if prediction>ERROR_THRESHOLD]
    #sort by strength of probability
    results.sort(key=lambda x: x[1], reverse=True)
    predicted_intent = []

    for result in results:
        predicted_intent.append({"intent": classes[result[0]], "probability": str(result[1])})
    return predicted_intent

def getResponse(predicted_intent, intents):
    result = "You possibly made a typo, please try again."
    if len(predicted_intent) >= 1:
        tag = predicted_intent[0]['intent']
        list_of_intents = intents['intents']
        for intent in list_of_intents:
            if(intent['tag'] == tag):
                result = random.choice(intent['responses'])
                break
    return result

def chatbot_response(player_message):
    data_file = open('pokerbot/intents.json').read()
    intents = json.loads(data_file)
    if player_message.isdigit():
        hand_score = int(math.floor( int(player_message)/ 1000000.0)) * 1000000
        player_message = str(hand_score)
    predicted_intent = predict_class(player_message,words,classes,model)
    botResponse = getResponse(predicted_intent,intents)
    return botResponse