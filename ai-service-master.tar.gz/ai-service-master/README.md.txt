Installed packages:
python -m pip install nltk
python -m pip install numpy
python -m pip install keras
python -m pip install tensorflow