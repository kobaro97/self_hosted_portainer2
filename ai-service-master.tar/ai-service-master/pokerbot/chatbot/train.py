from nltk.stem import WordNetLemmatizer
lemmatizer = WordNetLemmatizer()
import random
import numpy as np

def setup_training(words,classes,documents):
    #initializing training data
    training = []
    #Empty list for every single tag there is in the intent.json file.
    tag_list = [0] * len(classes)
    for doc in documents:
        #initializing bag of words
        contained_words = []
        #list of tokenized words for the pattern
        pattern_words = doc[0]
        #lemmatize each word
        pattern_words = [lemmatizer.lemmatize(pattern_word.lower()) for pattern_word in pattern_words]
        #create our bag of words with array 1, if word match found in current pattern
        for word in words:
            contained_words.append(1) if word in pattern_words else contained_words.append(0)
        #outpit is a 'O' for each tag and '1' for current tag (for each pattern)
        contained_tags = list(tag_list)
        contained_tags[classes.index(doc[1])] = 1
        
        training.append([contained_words,contained_tags])
        #shuffle our training list so its not always in the same order.
    random.shuffle(training)
    training = np.array(training)
    # create train and test lists. X - patterns, Y - intents

    training_set_patterns = list(training[:,0])
    training_set_intents = list(training[:,1])

    return training_set_patterns, training_set_intents