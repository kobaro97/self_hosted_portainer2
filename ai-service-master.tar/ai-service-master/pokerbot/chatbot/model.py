from keras.models import Sequential
from keras.models import load_model
from keras.layers import Dense, Activation, Dropout
import numpy as np


def create_and_train_model(training_set_patterns,training_set_intents):
    model = Sequential()
    model.add(Dense(128, input_shape=(len(training_set_patterns[0]),),activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(64,activation='relu'))
    model.add(Dropout(0.5))
    model.add(Dense(len(training_set_intents[0]), activation='softmax'))

    # adam seems to work better than SGD
    model.compile(loss='categorical_crossentropy',optimizer='adam', metrics=['accuracy'])

    #fitting and saving the model

    history = model.fit(np.array(training_set_patterns),np.array(training_set_intents),epochs=200,batch_size=4)
    model.save('pokerbot/chatbot/chatbot_model.h5',history)

    print("model created")